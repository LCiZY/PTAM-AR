#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int chemm_(char *side, char *uplo, integer *m, integer *n, complex *alpha, complex *a, integer *lda, complex *b, integer *ldb, complex *beta, complex *c__, integer *ldc);

#ifdef __cplusplus
}
#endif