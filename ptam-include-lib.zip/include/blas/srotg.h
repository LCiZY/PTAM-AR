#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int srotg_(real *sa, real *sb, real *c__, real *s);

#ifdef __cplusplus
}
#endif