#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zswap_(integer *n, doublecomplex *zx, integer *incx, doublecomplex *zy, integer *incy);

#ifdef __cplusplus
}
#endif