#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ccopy_(integer *n, complex *cx, integer *incx, complex *cy, integer *incy);

#ifdef __cplusplus
}
#endif