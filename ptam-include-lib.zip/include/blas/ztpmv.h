#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ztpmv_(char *uplo, char *trans, char *diag, integer *n, doublecomplex *ap, doublecomplex *x, integer *incx);

#ifdef __cplusplus
}
#endif