#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cher2_(char *uplo, integer *n, complex *alpha, complex *x, integer *incx, complex *y, integer *incy, complex *a, integer *lda);

#ifdef __cplusplus
}
#endif