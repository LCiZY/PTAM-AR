#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int strmm_(char *side, char *uplo, char *transa, char *diag, integer *m, integer *n, real *alpha, real *a, integer *lda, real *b, integer *ldb);

#ifdef __cplusplus
}
#endif