#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int xerbla_(char *srname, integer *info);

#ifdef __cplusplus
}
#endif