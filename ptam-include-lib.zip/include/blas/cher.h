#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cher_(char *uplo, integer *n, real *alpha, complex *x, integer *incx, complex *a, integer *lda);

#ifdef __cplusplus
}
#endif