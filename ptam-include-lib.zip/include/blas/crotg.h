#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int crotg_(complex *ca, complex *cb, real *c__, complex *s);

#ifdef __cplusplus
}
#endif