#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zdscal_(integer *n, doublereal *da, doublecomplex *zx, integer *incx);

#ifdef __cplusplus
}
#endif