#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zhpr_(char *uplo, integer *n, doublereal *alpha, doublecomplex *x, integer *incx, doublecomplex *ap);

#ifdef __cplusplus
}
#endif