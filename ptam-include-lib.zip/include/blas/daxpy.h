#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int daxpy_(integer *n, doublereal *da, doublereal *dx, integer *incx, doublereal *dy, integer *incy);

#ifdef __cplusplus
}
#endif