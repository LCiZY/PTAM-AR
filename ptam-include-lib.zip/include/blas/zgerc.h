#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zgerc_(integer *m, integer *n, doublecomplex *alpha, doublecomplex *x, integer *incx, doublecomplex *y, integer *incy, doublecomplex *a, integer *lda);

#ifdef __cplusplus
}
#endif