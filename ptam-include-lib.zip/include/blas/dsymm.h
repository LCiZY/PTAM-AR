#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dsymm_(char *side, char *uplo, integer *m, integer *n, doublereal *alpha, doublereal *a, integer *lda, doublereal *b, integer *ldb, doublereal *beta, doublereal *c__, integer *ldc);

#ifdef __cplusplus
}
#endif