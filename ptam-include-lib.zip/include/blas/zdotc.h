#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

Z_f zdotc_(doublecomplex * ret_val, integer *n, doublecomplex *zx, integer *incx, doublecomplex *zy, integer *incy);

#ifdef __cplusplus
}
#endif