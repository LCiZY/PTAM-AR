#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int drot_(integer *n, doublereal *dx, integer *incx, doublereal *dy, integer *incy, doublereal *c__, doublereal *s);

#ifdef __cplusplus
}
#endif