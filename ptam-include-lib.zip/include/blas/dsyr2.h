#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int dsyr2_(char *uplo, integer *n, doublereal *alpha, doublereal *x, integer *incx, doublereal *y, integer *incy, doublereal *a, integer *lda);

#ifdef __cplusplus
}
#endif