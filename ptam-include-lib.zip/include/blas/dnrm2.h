#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

doublereal dnrm2_(integer *n, doublereal *x, integer *incx);

#ifdef __cplusplus
}
#endif