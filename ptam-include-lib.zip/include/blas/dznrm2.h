#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

doublereal dznrm2_(integer *n, doublecomplex *x, integer *incx);

#ifdef __cplusplus
}
#endif