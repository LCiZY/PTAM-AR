#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int ssyrk_(char *uplo, char *trans, integer *n, integer *k, real *alpha, real *a, integer *lda, real *beta, real *c__, integer *ldc);

#ifdef __cplusplus
}
#endif