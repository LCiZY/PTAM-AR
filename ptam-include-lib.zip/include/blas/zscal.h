#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int zscal_(integer *n, doublecomplex *za, doublecomplex *zx, integer *incx);

#ifdef __cplusplus
}
#endif