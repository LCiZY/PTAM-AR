#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

E_f snrm2_(integer *n, real *x, integer *incx);

#ifdef __cplusplus
}
#endif