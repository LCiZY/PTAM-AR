#ifdef __cplusplus
extern "C" { 
#endif  

#include "f2c.h" 

int cscal_(integer *n, complex *ca, complex *cx, integer *incx);

#ifdef __cplusplus
}
#endif