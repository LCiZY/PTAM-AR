#pragma once

namespace mymath {
	template <class T>
	T mymax(T a, T b) {
		return a > b ? a : b;
	}
	template <class T>
	T mymin(T a, T b) {
		return a < b ? a : b;
	}
}